document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.querySelector('.menu-toggle');
    const nav = document.getElementById('main-nav');

    if (menuToggle && nav) {
        menuToggle.addEventListener('click', () => {
            const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true' || false;
            
            nav.classList.toggle('open');
            menuToggle.setAttribute('aria-expanded', !isExpanded);
            
            // Change hamburger icon to X when open, and back to hamburger when closed
            menuToggle.innerHTML = isExpanded ? '&#9776;' : '&#10005;';
        });

        // Close menu when a navigation link is clicked (internal anchor links)
        nav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (nav.classList.contains('open')) {
                    // Only apply closing logic if the screen is small enough for the menu to be active
                    if (window.innerWidth <= 768) { 
                        nav.classList.remove('open');
                        menuToggle.setAttribute('aria-expanded', 'false');
                        menuToggle.innerHTML = '&#9776;';
                    }
                }
            });
        });
    }
});